import unittest

from portfolio import analyze_portfolio, validate_portfolio


SAMPLE = {
    "cash": 100.0,
    "holdings": [
        {"symbol": "AAA", "quantity": 2, "current_price": 50, "average_cost": 40, "target_weight": 0.5},
        {"symbol": "BBB", "quantity": 1, "current_price": 100, "average_cost": 110, "target_weight": 0.5},
    ],
}


class PortfolioTests(unittest.TestCase):
    def test_totals(self):
        result = analyze_portfolio(SAMPLE)
        self.assertEqual(result["invested_value"], 200)
        self.assertEqual(result["portfolio_value"], 300)
        self.assertEqual(result["total_pnl"], 10)

    def test_target_weights(self):
        result = analyze_portfolio(SAMPLE)
        self.assertAlmostEqual(sum(row["current_weight"] for row in result["holdings"]), 1.0)
        self.assertAlmostEqual(sum(row["target_weight"] for row in result["holdings"]), 1.0)

    def test_rebalance_actions(self):
        result = analyze_portfolio(SAMPLE)
        self.assertEqual(result["holdings"][0]["action"], "HOLD")
        self.assertEqual(result["holdings"][1]["action"], "HOLD")

    def test_reject_bad_target_weights(self):
        invalid = {"cash": 0, "holdings": [dict(SAMPLE["holdings"][0], target_weight=0.4)]}
        with self.assertRaises(ValueError):
            validate_portfolio(invalid)

    def test_reject_duplicate_symbols(self):
        invalid = {"cash": 0, "holdings": [SAMPLE["holdings"][0], SAMPLE["holdings"][0]]}
        with self.assertRaises(ValueError):
            validate_portfolio(invalid)


if __name__ == "__main__":
    unittest.main()
