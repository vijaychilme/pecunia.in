"""Core portfolio calculations for the Fintech Portfolio Manager demo."""
from __future__ import annotations

from typing import Any


def validate_portfolio(portfolio: dict[str, Any]) -> None:
    """Raise ValueError when input data is invalid."""
    if "cash" not in portfolio or portfolio["cash"] < 0:
        raise ValueError("Portfolio must include non-negative cash.")
    holdings = portfolio.get("holdings", [])
    if not holdings:
        raise ValueError("Portfolio must contain at least one holding.")

    symbols = set()
    for holding in holdings:
        required = {"symbol", "quantity", "current_price", "average_cost", "target_weight"}
        missing = required - holding.keys()
        if missing:
            raise ValueError(f"{holding.get('symbol', 'Holding')}: missing {sorted(missing)}")
        if holding["symbol"] in symbols:
            raise ValueError(f"Duplicate symbol: {holding['symbol']}")
        symbols.add(holding["symbol"])
        if holding["quantity"] < 0 or holding["current_price"] < 0 or holding["average_cost"] < 0:
            raise ValueError(f"{holding['symbol']}: quantities and prices must be non-negative.")
        if holding["target_weight"] < 0:
            raise ValueError(f"{holding['symbol']}: target weight must be non-negative.")

    target_total = sum(h["target_weight"] for h in holdings)
    if abs(target_total - 1.0) > 1e-6:
        raise ValueError(f"Target weights must sum to 1.0; got {target_total:.4f}.")


def analyze_portfolio(portfolio: dict[str, Any]) -> dict[str, Any]:
    """Return portfolio totals, holding metrics, and hypothetical rebalance suggestions."""
    validate_portfolio(portfolio)
    rows = []
    invested_value = sum(h["quantity"] * h["current_price"] for h in portfolio["holdings"])

    if invested_value <= 0:
        raise ValueError("Invested value must be greater than zero.")

    for holding in portfolio["holdings"]:
        market_value = holding["quantity"] * holding["current_price"]
        cost_basis = holding["quantity"] * holding["average_cost"]
        pnl = market_value - cost_basis
        current_weight = market_value / invested_value
        target_value = invested_value * holding["target_weight"]
        trade_value = target_value - market_value
        rows.append({
            "symbol": holding["symbol"],
            "name": holding.get("name", holding["symbol"]),
            "quantity": holding["quantity"],
            "price": holding["current_price"],
            "market_value": market_value,
            "cost_basis": cost_basis,
            "pnl": pnl,
            "pnl_pct": (pnl / cost_basis * 100) if cost_basis else 0.0,
            "current_weight": current_weight,
            "target_weight": holding["target_weight"],
            "target_value": target_value,
            "trade_value": trade_value,
            "action": "BUY" if trade_value > 0.01 else "SELL" if trade_value < -0.01 else "HOLD",
        })

    cash = float(portfolio["cash"])
    return {
        "holdings": rows,
        "invested_value": invested_value,
        "cash": cash,
        "portfolio_value": invested_value + cash,
        "total_pnl": sum(row["pnl"] for row in rows),
    }


def export_csv(analysis: dict[str, Any], path: str = "portfolio_report.csv") -> None:
    """Export analyzed holdings to CSV using Python's standard library."""
    import csv

    fields = [
        "symbol", "name", "quantity", "price", "market_value", "cost_basis",
        "pnl", "pnl_pct", "current_weight", "target_weight", "target_value",
        "trade_value", "action",
    ]
    with open(path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for row in analysis["holdings"]:
            writer.writerow({key: row[key] for key in fields})
