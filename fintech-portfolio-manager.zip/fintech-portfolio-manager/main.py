"""Command-line entry point for the Fintech Portfolio Manager demo."""
import json
from pathlib import Path

from portfolio import analyze_portfolio, export_csv


def money(value: float) -> str:
    return f"${value:,.2f}"


def main() -> None:
    data_path = Path(__file__).with_name("sample_portfolio.json")
    with data_path.open(encoding="utf-8") as file:
        portfolio = json.load(file)

    report = analyze_portfolio(portfolio)

    print("\n=== FINTECH PORTFOLIO MANAGER ===")
    print("Fictional data | Educational demo only\n")
    print(f"Invested value : {money(report['invested_value'])}")
    print(f"Cash           : {money(report['cash'])}")
    print(f"Portfolio value: {money(report['portfolio_value'])}")
    print(f"Unrealized P/L : {money(report['total_pnl'])}\n")

    print(f"{'SYMBOL':<8}{'MARKET VALUE':>15}{'CURRENT':>12}{'TARGET':>12}{'P/L':>12}{'ACTION':>10}")
    print("-" * 69)
    for row in report["holdings"]:
        print(
            f"{row['symbol']:<8}{money(row['market_value']):>15}"
            f"{row['current_weight'] * 100:>11.1f}%"
            f"{row['target_weight'] * 100:>11.1f}%"
            f"{money(row['pnl']):>12}{row['action']:>10}"
        )
        if row["action"] != "HOLD":
            print(f"  Hypothetical {row['action'].lower()} amount: {money(abs(row['trade_value']))}")

    output_path = Path(__file__).with_name("portfolio_report.csv")
    export_csv(report, str(output_path))
    print(f"\nCSV report saved to: {output_path.name}")
    print("Note: suggestions ignore fees, taxes, and trading constraints; no trades are placed.")


if __name__ == "__main__":
    main()
